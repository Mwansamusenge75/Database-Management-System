<?php
session_start();

if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header("Location: admin_panel.php");
    exit();
}

if (!isset($_SESSION['user']) || !in_array($_SESSION['user']['role'], ['professor', 'CR'])) {
    header("Location: login.php");
    exit();
}

$user = $_SESSION['user'];
$username = "Welcome, " . $user['role'];

include 'db_connect.php';

$students = [];

$sql = "SELECT id, name FROM students";
if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_date = $_POST['class_date'];
    $status = $_POST['status'];
    $student_ids = isset($_POST['student_ids']) ? $_POST['student_ids'] : [];

    foreach ($student_ids as $student_id) {
        $sql_total_classes = "SELECT total_classes, present, absent FROM attendance_record WHERE student_id = ?";
        $stmt = $conn->prepare($sql_total_classes);
        $stmt->bind_param("i", $student_id);
        $stmt->execute();
        $stmt->bind_result($total_classes, $present, $absent);
        $stmt->fetch();
        $stmt->close();

        if ($total_classes === null) {
            $total_classes = 0;
            $present = 0;
            $absent = 0;
        }

        $total_classes += 1;
        if ($status == 'Present') {
            $present += 1;
        } elseif ($status == 'Absent') {
            $absent += 1;
        }

        $percentage = ($present / $total_classes) * 100;

        $sql_check = "SELECT id FROM attendance_record WHERE student_id = ? AND class_date = ?";
        $stmt = $conn->prepare($sql_check);
        $stmt->bind_param("is", $student_id, $class_date);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->close();
            $stmt = $conn->prepare("UPDATE attendance_record SET status = ?, total_classes = ?, present = ?, absent = ?, percentage = ? WHERE student_id = ? AND class_date = ?");
            $stmt->bind_param("siiiisi", $status, $total_classes, $present, $absent, $percentage, $student_id, $class_date);
        } else {
            $stmt->close();
            $stmt = $conn->prepare("INSERT INTO attendance_record (student_id, class_date, status, total_classes, present, absent, percentage) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("issiiii", $student_id, $class_date, $status, $total_classes, $present, $absent, $percentage);
        }

        $stmt->execute();
        $stmt->close();
    }

    header("Location: " . $_SERVER['PHP_SELF'] . "?success=1");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Attendance</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap">
   <style>
    body {
        font-family: 'Poppins', sans-serif;
        background: url('pexels-pixabay-159213.jpg') no-repeat center center fixed;
        background-size: cover;
        color: #333;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    .container {
        background: rgba(255, 255, 255, 0.85); 
        padding: 2rem;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        width: 100%;
        max-width: 1200px;
        margin: 20px;
        animation: fadeIn 0.5s ease-in-out;
        position: relative;
    }

.navbar {
  background-color:   #002855;
  padding: 1rem 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: white;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
  font-family: 'Poppins', sans-serif;
}


body {
  padding-top: 80px; 
}

.navbar-brand {
  font-size: 1.5rem;
  font-weight: 600;
  letter-spacing: 1px;
}

.navbar-links {
  display: flex;
  gap: 1rem;
}

.nav-btn {
  padding: 0.6rem 1.2rem;
  background: white;
  color: #0056b3;
  border-radius: 8px;
  text-decoration: none;
  font-weight: 500;
  transition: all 0.3s ease;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
}

.nav-btn:hover {
  background: #003f88;
  color: #fff;
  transform: translateY(-2px);
}

    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
        font-size: 1.8rem;
        color: #333;
    }

    .top-right-button {
        position: absolute;
        top: 20px;
        right: 20px;
    }

    .styled-table {
        width: 100%;
        border-collapse: collapse;
        font-family: 'Segoe UI', sans-serif;
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 0 8px rgba(0,0,0,0.1);
        overflow: hidden;
    }

    .styled-table thead tr {
        background-color:  #002855;
        color: white;
        text-align: left;
    }

    .styled-table th,
    .styled-table td {
        padding: 12px 15px;
    }

    .styled-table tbody tr:nth-child(even) {
        background-color: #f3f3f3;
    }

    #searchInput {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 6px;
        border: 1px solid #ccc;
    }
    
</style>

</head>
<body>
     <header class="navbar">
  <div class="navbar-brand">Information and Communications University</div>
  <nav class="navbar-links">
    <a href="dashboard.php" class="nav-btn">Back to dashboard</a>
    <a href="view_attendance.php" class="nav-btn">All Attendance Records</a>
  </nav>
</header>
    <div class="container">
        <h1>Manage Attendance</h1><?php echo $username; ?> 

        <form method="POST" action="">
            <label for="class_date">Class Date:</label>
            <input type="date" name="class_date" required><br><br>

            <label for="status">Attendance Status:</label>
            <select name="status" required>
                <option value="Present">Present</option>
                <option value="Absent">Absent</option>
                <option value="Excused">Excused</option>
            </select><br><br>

            <label for="student_ids">Search Student:</label><br>
            <input type="text" id="searchInput" placeholder="Search by name..."><br>

            <input type="checkbox" id="select_all" onclick="toggleSelectAll()"> <strong>Select All</strong><br><br>

            <table class="styled-table" id="studentTable">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student Name</th>
                        <th>Tick</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $index = 1; ?>
                    <?php foreach ($students as $student): ?>
                        <tr>
                            <td><?php echo $index++; ?></td>
                            <td><?php echo htmlspecialchars($student['name']); ?></td>
                            <td><input type="checkbox" name="student_ids[]" value="<?php echo $student['id']; ?>"></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <button type="submit">Submit Attendance</button>
        </form>
    </div>

    <script>
        function toggleSelectAll() {
            var checkboxes = document.querySelectorAll('input[name="student_ids[]"]');
            var selectAllCheckbox = document.getElementById('select_all');
            checkboxes.forEach(checkbox => {
                checkbox.checked = selectAllCheckbox.checked;
            });
        }

        document.getElementById('searchInput').addEventListener('keyup', function() {
            let filter = this.value.toLowerCase();
            let rows = document.querySelectorAll('#studentTable tbody tr');
            rows.forEach(row => {
                let studentName = row.cells[1].textContent.toLowerCase();
                row.style.display = studentName.includes(filter) ? '' : 'none';
            });
        });

        <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
        window.onload = function() {
            alert("✅ Attendance marked successfully!");
            if (history.replaceState) {
                const url = new URL(window.location);
                url.searchParams.delete("success");
                history.replaceState(null, '', url);
            }
        };
        <?php endif; ?>
    </script>
</body>
</html>

<?php $conn->close(); ?>
