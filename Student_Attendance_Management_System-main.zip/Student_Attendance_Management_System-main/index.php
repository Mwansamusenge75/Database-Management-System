<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Information and Communication University</title>
  <style>
    html, body {
      height: 100%;
      margin: 0;
      display: flex;
      flex-direction: column;
      font-family: Arial, sans-serif;
    }
    body {
      background-image: url('pexels-pixabay-159213.jpg');
      background-size: cover; 
      background-position: center; 
      background-attachment: fixed; 
      flex: 1 0 auto;
    }
    header {
      background-color: #002855;
      color: white;
      padding: 15px 15px;
      text-align: center;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .logo-container {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 10px;
    }
    .logo-container img {
      height: 60px;
      width: 60px;
      border-radius: 50%;
      object-fit: cover;
    }
    header h2 {
      margin: 0;
      font-size: 1.6rem;
    }
    header p {
      font-size: 0.95rem;
      margin-top: 8px;
      opacity: 0.85;
    }
    .container {
      max-width: 750px;
      margin: 80px auto;
      background-color: rgba(255, 255, 255, 0.8); 
      padding: 30px 10px;
      border-radius: 12px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.1);
      text-align: center;
      flex-grow: 1;
    }
    h1 {
      color: #002855;
      font-size: 2rem;
      margin-bottom: 15px;
    }
    p {
      font-size: 1.1rem;
      color: #444;
      margin-bottom: 35px;
    }
    .btn-group {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 20px;
    }
    .btn-group a {
      padding: 14px 30px;
      font-size: 1rem;
      font-weight: 500;
      background-color: #0056b3;
      color: white;
      border-radius: 6px;
      text-decoration: none;
      transition: 0.3s ease;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .btn-group a:hover {
      background-color: #003e8a;
      transform: translateY(-2px);
    }
    footer {
      background-color: #002855;
      color: white;
      padding: 15px 15px;
      text-align: center;
      box-shadow: 0 -2px 8px rgba(0,0,0,0.1);
      font-size: 1rem;
      flex-shrink: 0;
    }
    .footer-links {
      margin: 10px 0 5px 0;
    }
    .footer-links a {
      color: #aad8ff;
      margin: 0 12px;
      text-decoration: none;
      font-weight: 500;
    }
    .footer-links a:hover {
      text-decoration: underline;
    }
    .footer-credit {
      font-size: 0.9rem;
      margin-top: 5px;
      color: #cbd7ff;
    }
  </style>
</head>
<body>
 <header>
    <div class="logo-container">
      <img src="logo.jpg" alt="ICU Logo">
      <h2>Information and Communications University</h2>
    </div>
  </header>

  <div class="container">
    <h1>Welcome to the Student Attendance Management System</h1>
    <p>This platform helps manage attendance and view student attendance records with precision and ease.</p>

    <div class="btn-group">
      <a href="dashboard.php">Go to Dashboard</a>
      <a href="admin_panel.php">Admin Panel</a>
    </div>
  </div>

  <footer>
    <div class="footer-links">
      <a href="https://www.icuzambia.net" target="_blank" rel="noopener noreferrer">ICU Zambia</a> |
      <a href="https://www.zrdc.org" target="_blank" rel="noopener noreferrer">Zambia Research and Development Centre</a>
    </div>
    <div class="footer-credit">
      Designed and Maintained by Mwansa Jonathan Musenge SIN: 2303845080
    </div>
    &copy; <?php echo date("Y"); ?> Information and Communications University. All Rights Reserved.
  </footer>
</body>
</html>
