<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'student_attendance';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$success_message = '';
$error_message = '';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $name = $_POST['name'];

    
    if (empty($id) || empty($name)) {
        $error_message = "Student ID and Name are required.";
    } else {
        
        $sql = "SELECT id FROM students WHERE id = ?";
        $stmt_check = $conn->prepare($sql);
        if ($stmt_check) {
            $stmt_check->bind_param("i", $id);
            $stmt_check->execute();
            $stmt_check->store_result();

            if ($stmt_check->num_rows > 0) {
                $conn->begin_transaction();

                $sql = "INSERT INTO attendance_record (student_id, name, total_classes, present, absent, percentage)
                        SELECT student_id, name, 0, 0, 0, 0 FROM attendance WHERE student_id = ?
                        ON DUPLICATE KEY UPDATE name = VALUES(name), total_classes = 0, present = 0, absent = 0, percentage = 0";
                $stmt_update_attendance_record = $conn->prepare($sql);
                if ($stmt_update_attendance_record) {
                    $stmt_update_attendance_record->bind_param("i", $id);

                    if ($stmt_update_attendance_record->execute()) {
                        // Update attendance table
                        $sql = "UPDATE attendance SET name = ? WHERE student_id = ?";
                        $stmt_update_attendance = $conn->prepare($sql);
                        if ($stmt_update_attendance) {
                            $stmt_update_attendance->bind_param("si", $name, $id);

                            if ($stmt_update_attendance->execute()) {
                                $conn->commit();
                                $success_message = "Attendance record updated successfully!";
                            } else {
                                $conn->rollback();
                                $error_message = "Error updating attendance: " . $stmt_update_attendance->error;
                            }
                            $stmt_update_attendance->close();
                        } else {
                            $conn->rollback();
                            $error_message = "Error preparing attendance statement: " . $conn->error;
                        }
                    } else {
                        $conn->rollback();
                        $error_message = "Error updating attendance_record: " . $stmt_update_attendance_record->error;
                    }
                    $stmt_update_attendance_record->close();
                } else {
                    $conn->rollback();
                    $error_message = "Error preparing attendance_record statement: " . $conn->error;
                }
            } else {
                $error_message = "Student ID does not exist.";
            }
            $stmt_check->close();
        } else {
            $error_message = "Error preparing SELECT statement: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Attendance Record</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background: #fff;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            animation: fadeIn 0.5s ease-in-out;
        }

        h1 {
            text-align: center;
            margin-bottom: 1.5rem;
            font-size: 1.8rem;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #555;
        }

        input, button {
            padding: 0.8rem;
            margin-bottom: 1rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        input:focus {
            border-color: #6a11cb;
            box-shadow: 0 0 5px rgba(106, 17, 203, 0.5);
            outline: none;
        }

        button {
            background: #6a11cb;
            color: #fff;
            font-weight: 600;
            cursor: pointer;
            border: none;
        }

        button:hover {
            background: #2575fc;
            transform: translateY(-2px);
        }

        a {
            display: block;
            text-align: center;
            margin-top: 1rem;
            color: #6a11cb;
            text-decoration: none;
            font-weight: 500;
        }

        a:hover {
            text-decoration: underline;
        }

        .message {
            text-align: center;
            margin-bottom: 1rem;
            padding: 0.8rem;
            border-radius: 5px;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Update Attendance Record</h1>

        <?php if (!empty($success_message)) : ?>
            <div class="message success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if (!empty($error_message)) : ?>
            <div class="message error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="id">Student ID:</label>
            <input type="text" name="id" id="id" required>

            <label for="name">Name:</label>
            <input type="text" name="name" id="name" required>

            <button type="submit">Update</button>
        </form>

        <a href="index.php">Back to Home</a>
    </div>
</body>
</html>

<?php
$conn->close();
?>
